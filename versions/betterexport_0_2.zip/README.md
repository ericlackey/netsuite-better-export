# netsuite-better-export

NetSuite Better Export

## Summary

A Chrome extension for NetSuite that allows users to export Saved Search results in a more modern Excel version and other formats including HTML.

## Release Notes

### 0.1
- Initial release
